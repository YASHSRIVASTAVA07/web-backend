function showLoginForm() {
    window.location.href = 'login.html'; // Redirect to the login page
}

function showRegistrationForm() {
    window.location.href = 'index.html'; // Redirect to the registration page
}

function registerUser() {
    const name = document.getElementById('name').value;
    const email = document.getElementById('email').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;

    const data = { username: name, email, password, confirmPassword };

    fetch('/api/auth/register', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.msg === 'Registration successful') {
            alert('Registration successful. Redirecting to login page...');
            window.location.href = 'login.html'; // Redirect after successful registration
        } else {
            alert(data.msg || 'Registration failed. Please try again.');
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });

    return false;
}

function loginUser() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const data = { username, password };

    fetch('/api/auth/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.msg === 'Login successful') {
            alert('Login successful. Redirecting to welcome page...');
            window.location.href = 'welcome.html'; // Ensure the redirection to the welcome page
        } else {
            alert(data.msg || 'Login failed. Please try again.');
        }
    })
    .catch((error) => {
        console.error('Error:', error);
    });

    return false;
}

// Check for registration success message
document.addEventListener('DOMContentLoaded', function() {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('registered') === 'true') {
        alert('Account created successfully. You can now sign in.');
    }
});
